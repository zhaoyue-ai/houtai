import fetch from 'node-fetch'

// 配置信息
const API_KEY = process.env.VITE_QWEN_API_KEY || 'sk-02cd62cbd43d4694b863bd1a632392f2'
const API_URL = 'https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation'
// 清理 API Key 中的无效字符
function cleanApiKey(apiKey) {
    if (!apiKey) return ''
    
    // 移除可能的空格、换行、引号等
    return apiKey
      .trim()
      .replace(/[\n\r\t\s"']/g, '')
      .replace(/^Bearer\s*/i, '') // 移除已有的 Bearer 前缀
  }
   
  // 验证 API Key 格式
  function isValidApiKey(apiKey) {
    if (!apiKey) return false
    
    const cleaned = cleanApiKey(apiKey)
    
    // 千问 API Key 通常以 sk- 开头，长度约 32-64 字符
    return /^sk-[a-zA-Z0-9]{32,64}$/.test(cleaned)
  }

async function testQwenAPI() {
  console.log('🧪 开始测试千问 API Key...')
  console.log('🔑 API Key:', API_KEY ? '已配置' : '未配置')
  
  const cleanedApiKey = cleanApiKey(API_KEY)
  console.log('🔑 原始 API Key:', API_KEY ? '已配置' : '未配置')
  console.log('🔑 清理后 API Key:', cleanedApiKey ? cleanedApiKey : '空')
  
  if (!cleanedApiKey || !isValidApiKey(cleanedApiKey)) {
    console.error('❌ API Key 格式无效')
    console.error('💡 千问 API Key 应以 sk- 开头，包含 32-64 位字母数字')
    console.error('💡 当前 Key:', cleanedApiKey)
    return
  }
 

  try {
    console.log('📤 发送请求到千问 API...')
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${cleanedApiKey}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        "model": "qwen-turbo",
        "messages": [
            {
              "role": "user",
              "content": "你好，请回复'测试成功'来确认API Key有效"
            }
          ],
          "stream": false
      })
    })

    console.log('📊 响应状态:', response.status, response.statusText)
    
    if (response.ok) {
      const data = await response.json()
      console.log('✅ API Key 有效!')
      console.log('🤖 AI 回复:', data.output?.text || data)
    } else {
      const errorText = await response.text()
      console.error('❌ API Key 无效或请求失败')
      console.error('错误信息:', errorText)
      
      // 分析常见错误
      if (response.status === 401) {
        console.error('💡 可能原因: API Key 错误或已过期')
      } else if (response.status === 403) {
        console.error('💡 可能原因: 权限不足或额度用完')
      } else if (response.status === 404) {
        console.error('💡 可能原因: API 端点不存在')
      }
    }
    
  } catch (error) {
    console.error('❌ 测试过程中发生错误:')
    console.error(error.message)
    
    if (error.code === 'ENOTFOUND') {
      console.error('💡 可能原因: 网络连接问题，请检查网络')
    }
  }
}

// 运行测试
testQwenAPI()