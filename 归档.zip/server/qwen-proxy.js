import express from 'express'
import cors from 'cors'

const app = express()
const PORT = 3001

// 中间件
app.use(cors({
  origin: ['http://localhost:3006', 'http://127.0.0.1:3006'],
  credentials: true
}))
app.use(express.json())

// 千问 API 配置
const QWEN_API_KEY = process.env.VITE_QWEN_API_KEY || 'sk-02cd62cbd43d4694b863bd1a632392f2'
const QWEN_BASE_URL = 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions'

// 千问 API 请求格式转换函数
function convertToQwenFormat(requestData) {
  const messages = requestData.messages || [{ role: 'user', content: requestData.prompt || 'Hello' }]
  
  // 千问 API 格式：将 messages 转换为 input 和 history
  const input = messages[messages.length - 1]?.content || ''
  const history = messages.slice(0, -1).map(msg => ({
    user: msg.role === 'user' ? msg.content : undefined,
    bot: msg.role === 'assistant' ? msg.content : undefined
  })).filter(msg => msg.user || msg.bot)
  
  return {
    model: 'qwen-turbo',
    messages: messages.map(msg => ({
        role: msg.role,
        content: msg.content
      })),
      temperature: requestData.temperature || 0.7,
      max_tokens: requestData.maxTokens || 1000,
      stream: requestData.stream || false
  }
}

console.log('🚀 千问代理服务启动中...')
console.log('📊 配置信息:')
console.log('  - 端口:', PORT)
console.log('  - API Key:', QWEN_API_KEY ? '已配置' : '未配置')
console.log('  - 目标API:', QWEN_BASE_URL)

// 简单的测试端点
app.get('/api/qwen/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    service: '千问 API 代理',
    timestamp: new Date().toISOString(),
    message: '服务运行正常'
  })
})

// 千问聊天端点（简化版本）
app.post('/api/qwen/chat', async (req, res) => {
  try {
    console.log('📨 收到千问 API 请求')
    
    // 动态导入 node-fetch
    const fetch = (await import('node-fetch')).default
    
    // 转换为千问 API 格式
    const qwenRequestBody = convertToQwenFormat(req.body)
    
    console.log('📤 发送千问 API 请求:', JSON.stringify(qwenRequestBody, null, 2))
    
    const response = await fetch(QWEN_BASE_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${QWEN_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(qwenRequestBody)
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`千问 API 错误: ${response.status} - ${errorText}`)
    }

    const data = await response.json()
    console.log('✅ 千问 API 响应成功')
    res.json(data)
    
  } catch (error) {
    console.error('❌ 千问代理错误:', error.message)
    res.status(500).json({ 
      error: '千问 API 调用失败', 
      message: error.message,
      details: '请检查 API Key 和网络连接'
    })
  }
})

// 流式聊天端点 - 匹配前端请求
app.post('/api/qwen/chat/stream', async (req, res) => {
  try {
    console.log('🌊 收到流式聊天请求')
    
    // 动态导入 node-fetch
    const fetch = (await import('node-fetch')).default
    
    // 转换为千问 API 格式（流式版本）
    const qwenRequestBody = convertToQwenFormat({
        ...req.body,
        stream: true
      })
    
    // 千问流式 API 使用不同的端点
    const streamUrl = QWEN_BASE_URL.replace('/chat/completions', '/chat/completions/stream')
    
    console.log('📤 发送千问流式 API 请求:', JSON.stringify(qwenRequestBody, null, 2))
    
    const response = await fetch(QWEN_BASE_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${QWEN_API_KEY}`,
        'Content-Type': 'application/json',
        'X-DashScope-Async': 'enable'
      },
      body: JSON.stringify(qwenRequestBody)
    })

    if (!response.ok) {
      const errorText = await response.text()
      throw new Error(`千问 API 错误: ${response.status} - ${errorText}`)
    }

    // 设置流式响应头
    res.writeHead(200, {
      'Content-Type': 'text/plain; charset=utf-8',
      'Transfer-Encoding': 'chunked',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive'
    })

    // 流式转发响应
    response.body.pipe(res)
    
  } catch (error) {
    console.error('❌ 流式聊天错误:', error.message)
    res.status(500).json({ 
      error: '流式聊天失败', 
      message: error.message,
      details: '请检查 API Key 和网络连接'
    })
  }
})

// 启动服务
app.listen(PORT, () => {
  console.log(`✅ 千问 API 代理服务运行在 http://localhost:${PORT}`)
  console.log(`🔗 健康检查: http://localhost:${PORT}/api/qwen/health`)
  console.log(`💬 普通聊天: http://localhost:${PORT}/api/qwen/chat`)
  console.log(`🌊 流式聊天: http://localhost:${PORT}/api/qwen/chat/stream`)
})

export default app