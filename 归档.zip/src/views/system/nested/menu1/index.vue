<template>
  <div class="page-content">
    <h1>AI 功能演示</h1>

    <!-- 功能选择 -->
    <el-card class="feature-select-card">
      <template #header>
        <span class="font-bold feature-select-title">功能选择</span>
      </template>
      <el-radio-group v-model="activeTab" class="feature-select-group">
        <el-radio-button label="chat" class="feature-select-option">聊天对话</el-radio-button>
        <el-radio-button label="generate" class="feature-select-option">文本生成</el-radio-button>
        <el-radio-button label="batch" class="feature-select-option">批量生成</el-radio-button>
      </el-radio-group>
    </el-card>

    <!-- 聊天对话 -->
    <el-card v-if="activeTab === 'chat'" class="tab-card chat-card">
      <template #header>
        <span class="font-bold">AI 聊天助手</span>
      </template>

      <!-- 聊天筛选条件 -->
      <div class="chat-filter">
        <div class="chat-filter-row">
          <el-checkbox v-model="chatFilter.isAdmin">管理员身份（必须）</el-checkbox>
          <div class="chat-filter-age">
            <span class="chat-filter-label">年龄</span>
            <el-input-number
              v-model="chatFilter.age"
              :min="0"
              :max="150"
              :step="1"
              controls-position="right"
            />
          </div>
          <div class="chat-filter-status">
            <span v-if="canChat" class="status ok">已满足条件，可对话</span>
            <span v-else class="status warn">需要：管理员 且 年龄 &gt; 18</span>
          </div>
        </div>
      </div>

      <!-- 聊天记录 -->
      <div ref="chatContainerRef" class="chat-container">
        <div
          v-for="(message, index) in chatMessages"
          :key="index"
          :class="['message', message.role === 'user' ? 'user-message' : 'ai-message']"
        >
          <div class="message-content">{{ message.content }}</div>
          <div class="message-time">{{ message.timestamp }}</div>
        </div>

        <!-- AI 响应流 -->
        <div v-if="isGenerating" class="ai-response">
          <div class="typing-indicator">
            <span>AI 正在思考...</span>
            <div class="typing-dots">
              <span></span>
              <span></span>
              <span></span>
            </div>
          </div>
          <div class="response-content">{{ currentResponse }}</div>
        </div>
      </div>

      <!-- 输入框 -->
      <div class="input-container">
        <el-input
          v-model="userInput"
          type="textarea"
          :rows="3"
          placeholder="请输入您的问题..."
          :disabled="!canChat"
          @keydown.enter.prevent="handleSendMessage"
        />
        <el-button
          type="primary"
          class="mt-2"
          :loading="isGenerating"
          :disabled="!canChat"
          @click="handleSendMessage"
        >
          发送
        </el-button>
      </div>
    </el-card>

    <!-- 文本生成 -->
    <el-card v-if="activeTab === 'generate'" class="tab-card">
      <template #header>
        <span class="font-bold">文本生成</span>
      </template>

      <el-form :model="generateForm" label-width="80px">
        <el-form-item label="提示词">
          <el-input
            v-model="generateForm.prompt"
            type="textarea"
            :rows="3"
            placeholder="请输入生成内容的提示词"
          />
        </el-form-item>

        <el-form-item label="温度">
          <el-slider v-model="generateForm.temperature" :min="0" :max="1" :step="0.1" show-stops />
          <span class="ml-2 text-sm text-gray-500">{{ generateForm.temperature }}</span>
        </el-form-item>

        <el-form-item>
          <el-button type="primary" :loading="isGenerating" @click="handleGenerateText">
            生成文本
          </el-button>
        </el-form-item>
      </el-form>

      <!-- 生成结果 -->
      <div v-if="generatedText" class="result-container mt-4">
        <h3 class="text-lg font-semibold mb-2">生成结果：</h3>
        <div class="result-content p-4 bg-gray-50 rounded">
          {{ generatedText }}
        </div>
        <el-button class="mt-2" @click="copyToClipboard(generatedText)"> 复制结果 </el-button>
      </div>
    </el-card>

    <!-- 批量生成 -->
    <el-card v-if="activeTab === 'batch'" class="tab-card">
      <template #header>
        <span class="font-bold">批量文本生成</span>
      </template>

      <div class="batch-container">
        <div v-for="(prompt, index) in batchPrompts" :key="index" class="prompt-item mb-2">
          <el-input v-model="batchPrompts[index]" placeholder="请输入提示词" class="mr-2" />
          <el-button
            type="danger"
            size="small"
            @click="removePrompt(index)"
            :disabled="batchPrompts.length <= 1"
          >
            删除
          </el-button>
        </div>

        <el-button type="success" @click="addPrompt" class="mb-4"> 添加提示词 </el-button>

        <el-button type="primary" :loading="isBatchGenerating" @click="handleBatchGenerate">
          批量生成
        </el-button>

        <!-- 批量结果 -->
        <div v-if="batchResults.length > 0" class="batch-results mt-4">
          <h3 class="text-lg font-semibold mb-2">批量生成结果：</h3>
          <div
            v-for="(result, index) in batchResults"
            :key="index"
            class="result-item p-3 mb-2 bg-gray-50 rounded"
          >
            <div class="font-medium mb-1">提示词 {{ index + 1 }}：{{ batchPrompts[index] }}</div>
            <div class="text-sm">{{ result }}</div>
          </div>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script setup lang="ts">
  import { computed, ref, reactive } from 'vue'
  import { ElMessage } from 'element-plus'
  import { generateStream, chat, type ChatMessage, formatAIResponse } from '@/utils/ai'

  // 响应式数据
  const activeTab = ref('chat')

  // 聊天相关
  const userInput = ref('')
  const chatMessages = ref<Array<ChatMessage & { timestamp: string }>>([])
  const isGenerating = ref(false)
  const currentResponse = ref('')

  // 聊天筛选条件：管理员 + 年龄 > 18
  const chatFilter = reactive({
    isAdmin: false,
    age: 18
  })
  const canChat = computed(() => chatFilter.isAdmin && Number(chatFilter.age) > 18)

  // 文本生成相关
  const generateForm = reactive({
    prompt: '',
    temperature: 0.7
  })
  const generatedText = ref('')

  // 批量生成相关
  const batchPrompts = ref([''])
  const batchResults = ref<string[]>([])
  const isBatchGenerating = ref(false)
  const chatContainerRef = ref<HTMLElement>()
  // 格式化时间
  const formatTime = () => {
    return new Date().toLocaleTimeString('zh-CN', {
      hour: '2-digit',
      minute: '2-digit'
    })
  }
  // 自动滚动到底部
  const scrollToBottom = () => {
    nextTick(() => {
      if (chatContainerRef.value) {
        chatContainerRef.value.scrollTop = chatContainerRef.value.scrollHeight
      }
    })
  }
  // 发送消息
  const handleSendMessage = async () => {
    if (!canChat.value) {
      ElMessage.warning('需要管理员且年龄大于 18 才可以对话')
      return
    }
    if (isGenerating.value) return

    if (!userInput.value.trim()) {
      ElMessage.warning('请输入消息内容')
      return
    }

    // 添加用户消息
    chatMessages.value.push({
      role: 'user',
      content: userInput.value,
      timestamp: formatTime()
    })
    // 滚动到底部
    scrollToBottom()

    const userMessage = userInput.value
    userInput.value = ''
    isGenerating.value = true
    currentResponse.value = ''

    try {
      // 构建消息历史
      // const messages: ChatMessage[] = chatMessages.value
      //   .filter(msg => msg.role !== 'assistant')
      //   .map(msg => ({
      //     role: msg.role,
      //     content: msg.content
      //   }))
      // 优化：每次只发送当前消息，不包含历史记录
      const messages: ChatMessage[] = [
        {
          role: 'user',
          content: userMessage
        }
      ]
      // 调用 AI 聊天
      for await (const chunk of chat(messages)) {
        currentResponse.value += chunk
        // 滚动到底部
        scrollToBottom()
      }

      // 添加 AI 响应到消息列表
      chatMessages.value.push({
        role: 'assistant',
        content: formatAIResponse(currentResponse.value),
        timestamp: formatTime()
      })

      // 滚动到底部
      scrollToBottom()

      currentResponse.value = ''
    } catch (error) {
      ElMessage.error('聊天失败：' + (error as Error).message)
    } finally {
      isGenerating.value = false
    }
  }

  // 生成文本
  const handleGenerateText = async () => {
    if (!generateForm.prompt.trim()) {
      ElMessage.warning('请输入提示词')
      return
    }

    isGenerating.value = true
    generatedText.value = ''

    try {
      let fullText = ''
      for await (const chunk of generateStream(generateForm.prompt, {
        temperature: generateForm.temperature
      })) {
        fullText += chunk
        generatedText.value = fullText
      }

      generatedText.value = formatAIResponse(fullText)
      ElMessage.success('文本生成成功')
    } catch (error) {
      ElMessage.error('文本生成失败：' + (error as Error).message)
    } finally {
      isGenerating.value = false
    }
  }

  // 批量生成
  const handleBatchGenerate = async () => {
    const validPrompts = batchPrompts.value.filter((p) => p.trim())
    if (validPrompts.length === 0) {
      ElMessage.warning('请至少输入一个有效的提示词')
      return
    }

    isBatchGenerating.value = true
    batchResults.value = []

    try {
      for (const prompt of validPrompts) {
        let fullText = ''
        for await (const chunk of generateStream(prompt)) {
          fullText += chunk
        }
        batchResults.value.push(formatAIResponse(fullText))
      }

      ElMessage.success(`成功生成 ${batchResults.value.length} 个结果`)
    } catch (error) {
      ElMessage.error('批量生成失败：' + (error as Error).message)
    } finally {
      isBatchGenerating.value = false
    }
  }

  // 添加提示词
  const addPrompt = () => {
    batchPrompts.value.push('')
  }

  // 删除提示词
  const removePrompt = (index: number) => {
    batchPrompts.value.splice(index, 1)
    if (batchResults.value.length > index) {
      batchResults.value.splice(index, 1)
    }
  }

  // 复制到剪贴板
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      ElMessage.success('已复制到剪贴板')
    } catch {
      ElMessage.error('复制失败')
    }
  }
</script>

<style scoped>
  .page-content {
    height: 100vh;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  }

  .tab-card {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
  }

  :deep(.tab-card .el-card__body) {
    flex: 1;
    min-height: 0;
    overflow: auto;
    display: flex;
    flex-direction: column;
  }

  /* 聊天卡片：消息区单独滚动 */
  :deep(.chat-card .el-card__body) {
    overflow: hidden;
  }

  :deep(.feature-select-card) {
    border-radius: 12px;
  }

  :deep(.feature-select-card .el-card__header) {
    background: #f8fafc;
    border-bottom: 1px solid #edf0f6;
    padding: 14px 20px;
  }

  .feature-select-title {
    font-size: 15px;
    letter-spacing: 0.2px;
    color: #111827;
  }

  :deep(.feature-select-card .el-card__body) {
    padding: 16px 20px;
  }

  .feature-select-group {
    display: flex;
    gap: 12px;
    flex-wrap: wrap;
  }

  :deep(.feature-select-group .el-radio-button) {
    margin: 0;
  }

  /* 覆盖 Element Plus radio-button 的默认外观，让三个选项更统一、更“按钮化” */
  :deep(.feature-select-group .el-radio-button__inner) {
    padding: 10px 16px;
    border-radius: 10px;
    font-weight: 600;
    color: #4b5563;
    border: 1px solid #dfe7f3;
    background: #ffffff;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
  }

  :deep(.feature-select-group .el-radio-button.is-active .el-radio-button__inner) {
    color: #ffffff;
    background: #409eff;
    border-color: #409eff;
    box-shadow: 0 10px 22px rgba(64, 158, 255, 0.25);
  }

  :deep(.feature-select-group .el-radio-button.is-focus .el-radio-button__inner) {
    border-color: #7cb8ff;
  }

  .chat-container {
    flex: 1;
    min-height: 0;
    max-height: none;
    overflow-y: auto;
    border: 1px solid #e5e7eb;
    border-radius: 12px;
    padding: 16px;
    background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
  }

  .message {
    margin-bottom: 14px;
    padding: 12px 14px;
    border-radius: 12px;
    max-width: 72%;
    position: relative;
    box-shadow: 0 1px 8px rgba(16, 24, 40, 0.04);
    width: fit-content;
  }

  .user-message {
    background-color: #409eff;
    border: 1px solid rgba(64, 158, 255, 0.35);
    color: white;
    margin-left: auto;
    text-align: right;
  }

  .ai-message {
    background-color: #f5f7fa;
    border: 1px solid #e7edf5;
    color: #606266;
    margin-right: auto;
  }

  .message-content {
    margin-bottom: 4px;
    white-space: pre-wrap;
    word-break: break-word;
    line-height: 1.6;
    font-size: 14px;
  }

  .message-time {
    font-size: 12px;
    opacity: 0.7;
    align-self: flex-end;
  }

  .ai-response {
    background-color: #f0f9ff;
    border: 1px solid #bae6fd;
    border-radius: 12px;
    padding: 12px 14px;
    margin-top: 8px;
    margin-right: auto;
    width: fit-content;
    max-width: 72%;
    box-shadow: 0 1px 8px rgba(16, 24, 40, 0.04);
  }

  .ai-response .response-content {
    white-space: pre-wrap;
    word-break: break-word;
    line-height: 1.6;
    font-size: 14px;
    color: inherit;
  }

  .ai-message .message-time,
  .ai-response .message-time {
    align-self: flex-start;
  }

  /* 气泡“尾巴” */
  .message::after {
    content: '';
    position: absolute;
    top: 14px;
    width: 10px;
    height: 10px;
    transform: rotate(45deg);
    border-radius: 2px;
  }

  .user-message::after {
    right: -5px;
    background-color: #409eff;
  }

  .ai-message::after {
    left: -5px;
    background-color: #f5f7fa;
  }

  .typing-indicator {
    display: flex;
    align-items: center;
    color: #666;
    font-size: 14px;
    margin-bottom: 8px;
  }

  .typing-dots {
    display: flex;
    margin-left: 8px;
  }

  .typing-dots span {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background-color: #94a3b8;
    margin: 0 2px;
    animation: typing 1.4s infinite ease-in-out;
  }

  .typing-dots span:nth-child(2) {
    animation-delay: 0.2s;
  }

  .typing-dots span:nth-child(3) {
    animation-delay: 0.4s;
  }

  @keyframes typing {
    0%,
    60%,
    100% {
      transform: translateY(0);
    }
    30% {
      transform: translateY(-4px);
    }
  }

  .input-container {
    display: flex;
    flex-direction: column;
    gap: 10px;
    flex-shrink: 0;
  }

  .chat-filter {
    flex-shrink: 0;
    margin-bottom: 12px;
    padding: 12px 14px;
    border: 1px solid #e5e7eb;
    border-radius: 14px;
    background: rgba(255, 255, 255, 0.9);
    box-shadow: 0 6px 18px rgba(16, 24, 40, 0.04);
  }

  .chat-filter-row {
    display: flex;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
  }

  .chat-filter-age {
    display: flex;
    align-items: center;
    gap: 10px;
  }

  .chat-filter-label {
    font-size: 13px;
    color: #6b7280;
    font-weight: 600;
  }

  .chat-filter-status {
    margin-left: auto;
  }

  .chat-filter-status .status {
    font-size: 13px;
    font-weight: 700;
  }

  .chat-filter-status .ok {
    color: #16a34a;
  }

  .chat-filter-status .warn {
    color: #f59e0b;
  }

  :deep(.input-container .el-textarea__inner) {
    border-radius: 12px;
    font-size: 14px;
    padding: 10px 12px;
  }

  :deep(.input-container .el-input__wrapper) {
    border-radius: 12px;
    padding: 0;
  }

  :deep(.input-container .el-textarea__inner::placeholder) {
    color: #9ca3af;
  }

  .input-container :deep(.el-button--primary) {
    border-radius: 10px;
    height: 40px;
  }

  .input-container :deep(.el-button) {
    align-self: flex-end;
  }

  .batch-container .prompt-item {
    display: flex;
    align-items: center;
  }

  .result-container {
    border-top: 1px solid #e4e7ed;
    padding-top: 16px;
  }

  .result-content {
    white-space: pre-wrap;
    line-height: 1.6;
  }

  .batch-results .result-item {
    border-left: 4px solid #409eff;
  }
</style>
