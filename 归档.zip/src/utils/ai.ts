// 直接使用 fetch API 调用后端代理服务
const QWEN_PROXY_URL = import.meta.env.VITE_QWEN_PROXY_URL || 'http://localhost:3001/api/qwen'

// 检查 API Key 配置
const checkApiKey = () => {
  const apiKey = import.meta.env.VITE_QWEN_API_KEY
  if (!apiKey) {
    throw new Error(
      '通义千问 API Key 未配置。请设置 VITE_QWEN_API_KEY 环境变量。\n' +
      '获取地址：https://dashscope.aliyun.com/\n' +
      '免费试用：新用户可免费获取一定额度的 API 调用权限'
    )
  }
  return apiKey
}

/**
 * 流式文本生成
 * @param prompt 提示词
 * @param options 配置选项
 */
export async function* generateStream(prompt: string, options?: {
  temperature?: number
  maxTokens?: number
  systemPrompt?: string
}) {
  try {
    checkApiKey()
    
    const response = await fetch(`${QWEN_PROXY_URL}/chat/stream`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prompt,
        temperature: options?.temperature ?? 0.7,
        maxTokens: options?.maxTokens ?? 1000,
        systemPrompt: options?.systemPrompt
      })
    })

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${await response.text()}`)
    }

    const reader = response.body?.getReader()
    if (!reader) {
      throw new Error('无法读取流式响应')
    }

    const decoder = new TextDecoder()
    let buffer = ''
    try {
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        
        const chunk = decoder.decode(value, { stream: true })
        buffer += chunk
        
        // 解析 SSE 格式：以 \n\n 分隔的 data: 消息
        const lines = buffer.split('\n')
        buffer = lines.pop() || '' // 保留未完成的行
        
        
        for (const line of lines) {
            const trimmedLine = line.trim()
            
            // 跳过空行
            if (!trimmedLine) continue
            
            // 处理 data: 开头的消息
            if (trimmedLine.startsWith('data: ')) {
              const data = trimmedLine.slice(6).trim() // 移除 'data: ' 前缀并去除空格
              
              // 检查流结束标记
              if (data === '[DONE]') {
                return
              }
              
              // 处理 JSON 数据
              if (data) {
                try {
                  const parsed = JSON.parse(data)
                  
                  // 提取 AI 回复内容 - 针对千问 API 的 OpenAI 兼容格式
                  let content = ''
                  
                  // 格式1: OpenAI 兼容格式（千问返回的格式）
                  if (parsed.choices && Array.isArray(parsed.choices) && parsed.choices.length > 0) {
                    const choice = parsed.choices[0]
                    
                    // 处理 delta 格式（流式响应）
                    if (choice.delta && choice.delta.content !== undefined) {
                      content = choice.delta.content
                    }
                    // 处理 message 格式（非流式响应）
                    else if (choice.message && choice.message.content) {
                      content = choice.message.content
                    }
                  }
                  // 格式2: 直接 content 字段
                  else if (parsed.content) {
                    content = parsed.content
                  }
                  // 格式3: 输出文本格式
                  else if (parsed.output?.text) {
                    content = parsed.output.text
                  }
                  
                  // 如果有内容则返回（空字符串也需要处理，因为可能是流式开始）
                  if (content !== undefined) {
                    yield content
                  }
                  
                } catch (e) {
                  // 如果 JSON 解析失败，可能是原始文本，直接返回
                  console.warn('JSON 解析失败，尝试作为文本处理:', data.substring(0, 50))
                  yield data
                }
              }
            } else {
              // 如果不是 data: 开头的行，可能是原始文本，直接返回
              yield trimmedLine
            }
          }
        }
    } finally {
      reader.releaseLock()
    }
    
  } catch (error) {
    throw new Error(`AI 生成失败: ${(error as Error).message}`)
  }
}

/**
 * 批量文本生成
 * @param prompts 提示词数组
 */
export async function generateBatch(prompts: string[]) {
  try {
    const results = await Promise.all(
      prompts.map(prompt => 
        streamText({
          model,
          prompt,
          temperature: 0.7
        }).textStream
      )
    )
    
    return results
  } catch (error) {
    throw new Error(`批量生成失败: ${(error as Error).message}`)
  }
}

/**
 * 聊天对话功能
 */
export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

export async function* chat(messages: ChatMessage[]) {
  try {
    checkApiKey()
    
    const response = await fetch(`${QWEN_PROXY_URL}/chat/stream`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        messages: messages.map(msg => ({
          role: msg.role,
          content: msg.content
        }))
      })
    })

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${await response.text()}`)
    }

    const reader = response.body?.getReader()
    if (!reader) {
      throw new Error('无法读取流式响应')
    }

    const decoder = new TextDecoder()
    let buffer = ''
    try {
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        
        const chunk = decoder.decode(value, { stream: true })
        buffer += chunk
        
        // 解析 SSE 格式：处理每一行
        const lines = buffer.split('\n')
        buffer = lines.pop() || '' // 保留未完成的行
        
        for (const line of lines) {
          const trimmedLine = line.trim()
          
          // 跳过空行
          if (!trimmedLine) continue
          
          // 处理 data: 开头的消息
          if (trimmedLine.startsWith('data: ')) {
            const data = trimmedLine.slice(6).trim() // 移除 'data: ' 前缀并去除空格
            
            // 检查流结束标记
            if (data === '[DONE]') {
              return
            }
            
            // 处理 JSON 数据
            if (data) {
              try {
                const parsed = JSON.parse(data)
                
                // 直接提取 content 内容 - 简化逻辑
                if (parsed.choices && parsed.choices[0]?.delta?.content !== undefined) {
                  yield parsed.choices[0].delta.content
                }
                
              } catch (e) {
                // 如果 JSON 解析失败，直接跳过这行数据
                console.warn('JSON 解析失败，跳过数据:', data.substring(0, 50))
              }
            }
          }
        }
      }
    } finally {
      reader.releaseLock()
    }
    
  } catch (error) {
    throw new Error(`聊天失败: ${(error as Error).message}`)
  }
}

/**
 * 工具函数：格式化 AI 响应
 */
export function formatAIResponse(text: string): string {
  return text
    .replace(/\n{3,}/g, '\n\n') // 限制连续换行
    .trim()
}

export default {
  generateStream,
  generateBatch,
  chat,
  formatAIResponse
}